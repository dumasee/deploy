pc=$(ps -ef | grep "yb-admin" | grep "java" | grep 8085 | grep -v grep|wc -l)
echo $pc
if [ $pc -eq 0 ];then
        mv admin.log "admin.log.`date +'%F-%T'`"
	#nohup java -jar -Dspring.profiles.active=prod yb-admin-qdmate-1.0.0.jar --spring.profiles.active=test --server.port=8085 2>&1 >> admin.log &
	nohup java -jar -Dspring.profiles.active=test yb-admin-qdmate-1.0.0.jar --spring.profiles.active=test --server.port=8085 2>&1 >> admin.log &
fi
