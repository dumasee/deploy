pc=$(ps -ef | grep "yb-fixreptoken" | grep "java" | grep 8087 | grep -v grep|wc -l)
echo $pc
if [ $pc -eq 0 ];then
        mv tokenfix.log "tokenfix.log.`date +'%F-%T'`"
	nohup java -jar -Dspring.profiles.active=prod yb-fixreptoken.jar --spring.profiles.active=prod --config.task.run=true --server.port=8087 2>&1 >> tokenfix.log &
fi
