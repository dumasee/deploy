pc=$(ps -ef | grep "yb-admin" | grep "java" | grep 8086 | grep -v grep|wc -l)
echo $pc
if [ $pc -eq 0 ];then
        mv task.log "task.log.`date +'%F-%T'`"
	nohup java -jar -Dspring.profiles.active=prod yb-admin-1.0.0.jar --spring.profiles.active=prod --config.task.run=true --server.port=8086 2>&1 >> task.log &
fi
