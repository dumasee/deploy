pc=$(ps -ef | grep "yb-portal-qdmate" | grep "java" | grep 8082 | grep -v grep|wc -l)
echo $pc
if [ $pc -eq 0 ];then
        mv portal.log "portal.log.`date +'%F-%T'`"
	#nohup java -jar -Dspring.profiles.active=test yb-portal-qdmate-1.0.0.jar --spring.profiles.active=test --server.port=8082 2>&1 >> portal.log  & 
	nohup java -jar -Dspring.profiles.active=test yb-portal-qdmate-1.0.0.jar --spring.profiles.active=test --server.port=8082 2>&1 >> portal.log  & 
fi
